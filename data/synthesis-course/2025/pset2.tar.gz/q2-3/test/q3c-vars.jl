using Test
using q23: drawing_corpus, find_component_and_rewrite, ComponentSearchConfig, parse_exp

@testset "q3c-vars" begin
    expected_components = [
        "(repeat \$2 (move (/ tau \$2) \$1 done) done)",
        "(repeat \$3 (penup (move (/ tau \$3) 4 done) (#component1 \$2 \$1)) done)",
        "(move (/ tau \$2) \$1 done)"
    ]
    corpus, grammar = drawing_corpus()
    config = ComponentSearchConfig(grammar, false, 3)
    for i in 1:3
        component_result = find_component_and_rewrite(corpus, config, Symbol("component$i"))
        println(component_result)
        println(corpus)
        @test string(component_result.component.e) == expected_components[i]
    end
end
