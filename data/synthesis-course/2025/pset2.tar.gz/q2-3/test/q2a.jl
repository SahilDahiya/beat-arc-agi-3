using Test
using q23: expand_inner, unexpand_inner, Grammar, parse_exp, get_production, drawing_grammar

function compare(e_str, production, expected_result)
    println("Expanding $e_str with $production and expecting $expected_result")
    e = parse_exp(e_str)
    expand_inner(e, production)
    @test e == parse_exp(expected_result)
    println("Trying to unexpand $e back to $e_str")
    unexpand_inner(e, production.return_type)
    @test e == parse_exp(e_str)
end

@testset "q2a" begin
    grammar = drawing_grammar()
    production_done = get_production(grammar, :cmd, :done)
    production_move = get_production(grammar, :cmd, :move)
    production_tau = get_production(grammar, :angle, :tau)
    production_div = get_production(grammar, :angle, :/)
    production_const_4 = get_production(grammar, :num, :const; data=4)
    production_tau = get_production(grammar, :angle, :tau)

    # expand ?const -> 4
    compare("?num", production_const_4, "4")
    compare("?cmd", production_done, "done")
    compare("?cmd", production_move, "(move ?angle ?num ?cmd)")
    compare("?angle", production_tau, "tau")
    compare("?angle", production_div, "(/ ?angle ?num)")

    # make sure it works within a larger expression
    e = parse_exp("?cmd")
    expand_inner(e, production_move)
    @test e == parse_exp("(move ?angle ?num ?cmd)")
    expand_inner(e.args[3], production_done)
    @test e == parse_exp("(move ?angle ?num done)")
    unexpand_inner(e.args[3], production_done.return_type)
    @test e == parse_exp("(move ?angle ?num ?cmd)")
    unexpand_inner(e, production_move.return_type)
    @test e == parse_exp("?cmd")
end