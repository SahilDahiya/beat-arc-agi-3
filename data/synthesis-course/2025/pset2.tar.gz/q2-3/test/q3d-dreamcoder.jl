using Test
using q23: drawing_grammar, drawing_tasks, solve_all, find_component_and_rewrite, drawing_correctness, Corpus, ComponentSearchConfig, issuccess


function test_dreamcoder()
    grammar = drawing_grammar()
    tasks = drawing_tasks()

    max_weight = 8.0
    max_expansions = typemax(Int) # 50000000

    for iteration in 1:2
        printstyled("Iteration $iteration\n", color=:yellow)
        results = solve_all(tasks, grammar; max_weight, max_expansions, threads=true)

        solved = [(result.solution, task) for (result, task) in zip(results, tasks) if issuccess(result)]

        programs = [solution for (solution, _) in solved]
        types = [task.type for (_, task) in solved]
        names = [task.name for (_, task) in solved]

        corpus = Corpus(programs, types, names, grammar)
        config = ComponentSearchConfig(grammar, false, 3)
        component_result = find_component_and_rewrite(corpus, config, Symbol("component$iteration"))
        println(component_result)
        println(corpus)

        # make sure they still work after rewriting
        for (solution, task) in solved
            @assert drawing_correctness(task)(solution)
        end
    end
end

@testset "q3d-dreamcoder" begin
    test_dreamcoder()
end