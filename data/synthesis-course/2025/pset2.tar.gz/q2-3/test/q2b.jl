using Test
using q23: expand, unexpand, Grammar, parse_exp, TopDownSearch, TopDownConfig, TopDownSearchResult, Stats, drawing_grammar, new_hole, SubExp, holetype, get_production

@testset "q2b" begin
    grammar = drawing_grammar()
    config = TopDownConfig(grammar, (_) -> false, 0.0, 10.0, 10000, :cmd, false, false)
    e = new_hole(:cmd)
    search = TopDownSearch(e, 0.0, [SubExp(e, holetype(e), Int[])], config, TopDownSearchResult(nothing, 0.0, Stats(0, 0)))

    println("expand ?cmd -> (move ?angle ?num ?cmd)")
    production1 = get_production(grammar, :cmd, :move)
    hole1 = pop!(search.holes)
    expand(hole1, production1, search)
    @test search.e == parse_exp("(move ?angle ?num ?cmd)")
    @test isapprox(search.weight, production1.weight)
    @test length(search.holes) == 3
    @test search.holes[1].e == parse_exp("?angle")
    @test search.holes[1].type == :angle
    @test search.holes[1].zipper == [1]
    @test search.holes[2].e == parse_exp("?num")
    @test search.holes[2].type == :num
    @test search.holes[2].zipper == [2]
    @test search.holes[3].e == parse_exp("?cmd")
    @test search.holes[3].type == :cmd
    @test search.holes[3].zipper == [3]


    println("expand (move ?angle ?num ?cmd) -> (move ?angle ?num done)")
    production2 = get_production(grammar, :cmd, :done)
    hole2 = pop!(search.holes)
    expand(hole2, production2, search)
    @test search.e == parse_exp("(move ?angle ?num done)")
    @test isapprox(search.weight, production1.weight + production2.weight)
    @test length(search.holes) == 2
    @test search.holes[1].e == parse_exp("?angle")
    @test search.holes[2].e == parse_exp("?num")


    println("expand (move ?angle ?num done) -> (move ?angle 5 done)")
    production3 = get_production(grammar, :num, :const; data=5)
    hole3 = pop!(search.holes)
    expand(hole3, production3, search)
    @test search.e == parse_exp("(move ?angle 5 done)")
    @test isapprox(search.weight, production1.weight + production2.weight + production3.weight)
    @test length(search.holes) == 1
    @test search.holes[1].e == parse_exp("?angle")

    println("unexpand (move ?angle 5 done) -> (move ?angle ?num done)")
    unexpand(hole3, production3, search)
    push!(search.holes, hole3)
    @test search.e == parse_exp("(move ?angle ?num done)")
    @test isapprox(search.weight, production1.weight + production2.weight)
    @test length(search.holes) == 2
    @test search.holes[1].e == parse_exp("?angle")
    @test search.holes[2].e == parse_exp("?num")

    println("unexpand (move ?angle ?num done) -> (move ?angle ?num ?cmd)")
    unexpand(hole2, production2, search)
    push!(search.holes, hole2)
    @test search.e == parse_exp("(move ?angle ?num ?cmd)")
    @test isapprox(search.weight, production1.weight)
    @test length(search.holes) == 3
    @test search.holes[1].e == parse_exp("?angle")
    @test search.holes[2].e == parse_exp("?num")
    @test search.holes[3].e == parse_exp("?cmd")
end
