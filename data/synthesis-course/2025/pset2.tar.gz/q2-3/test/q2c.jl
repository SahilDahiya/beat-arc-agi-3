using Test
using q23: drawing_tasks, drawing_grammar, solve_task, issuccess

function get_task(name::String, tasks)
    return tasks[findfirst(task -> task.name == name, tasks)]
end

tasks_2c = ["Line", "Triangle", "Pentagon"]

@testset "q2c" begin
    tasks = drawing_tasks()
    grammar = drawing_grammar()
    for task in tasks_2c
        println("Solving $task")
        result = solve_task(get_task(task, tasks); max_weight=10.0, grammar, verbose=true)
        @test issuccess(result)
    end
end