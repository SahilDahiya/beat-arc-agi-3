using Test
using JSON
using q23: drawing_corpus, find_component_and_rewrite, ComponentSearchConfig, parse_exp, Corpus, naive_grammar

function nuts_and_bolts_corpus()
    programs = open("data/nuts-bolts.json", "r") do f
        data = JSON.parse(f)
        parse_exp.(data)
    end
    types = fill(:any, length(programs))
    names = ["$i" for i in 1:length(programs)]
    grammar = naive_grammar(programs)
    corpus = Corpus(programs, types, names, grammar)
    return corpus, grammar
end

@testset "q3d-scaling" begin

    expected_components = [
        "(T (repeat (T l (M 1 0 -0.5 (/ 0.5 (tan (/ pi \$2))))) \$2 (M 1 (/ (* 2 pi) \$2) 0 0)) (M \$1 0 0 0))",
        "(repeat (T l (M 1 0 -0.5 (/ 0.5 (tan (/ pi \$1))))) \$1 (M 1 (/ (* 2 pi) \$1) 0 0))",
        "(repeat (T (T \$3 (M 0.5 0 0 0)) (M 1 0 (* \$2 (cos (/ pi 4))) (* \$2 (sin (/ pi 4))))) \$1 (M 1 (/ (* 2 pi) \$1) 0 0))"
    ]

    corpus, grammar = nuts_and_bolts_corpus()
    config = ComponentSearchConfig(grammar, false, 3)
    for i in 1:3
        component_result = find_component_and_rewrite(corpus, config, Symbol("component$i"))
        println(component_result)
        printstyled(component_result.stats, "\n", color=:yellow)
        @test component_result.component.e == parse_exp(expected_components[i])
    end
end