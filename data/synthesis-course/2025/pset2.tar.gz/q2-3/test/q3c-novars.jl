using Test
using q23: drawing_corpus, find_component_and_rewrite, ComponentSearchConfig, parse_exp

@testset "q3c-novars" begin

    expected_components = [
        "(repeat inf (move (/ tau inf) (* eps 6) done) done)",
        "(repeat 5 (move (/ tau 5) 2 done) done)",
        "(repeat 4 (move (/ tau 4) 3 done) done)"
    ]

    corpus, grammar = drawing_corpus()
    config = ComponentSearchConfig(grammar, false, 0)
    for i in 1:3
        component_result = find_component_and_rewrite(corpus, config, Symbol("component$i"))
        println(component_result)
        println(corpus)
        @test component_result.component.e == parse_exp(expected_components[i])
    end
end
