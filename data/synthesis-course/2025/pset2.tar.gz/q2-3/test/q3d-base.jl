using Test
using q23: drawing_corpus, find_component_and_rewrite, ComponentSearchConfig, parse_exp, upper_bound, init_component, Exp

@testset "q3d-base" begin
    expected_component = "(repeat \$2 (move (/ tau \$2) \$1 done) done)"

    corpus, grammar = drawing_corpus()
    config = ComponentSearchConfig(grammar, false, 3)
    component = init_component(corpus, config, :num, Symbol("component1"))

    # test upper bound
    @test isapprox(upper_bound(Exp[]), 0.0)
    @test isapprox(upper_bound(component.matches), 50.0)

    printstyled("WITH PRUNING\n", color=:blue)
    corpus, grammar = drawing_corpus()
    config = ComponentSearchConfig(grammar, false, 3)
    component_result = find_component_and_rewrite(corpus, config, Symbol("component1"))
    println(component_result)
    printstyled(component_result.stats, "\n", color=:yellow)
    @test string(component_result.component.e) == expected_component

    printstyled("WITHOUT PRUNING\n", color=:blue)

    corpus, grammar = drawing_corpus()
    config = ComponentSearchConfig(grammar, true, 3)
    component_result = find_component_and_rewrite(corpus, config, Symbol("component1"))
    println(component_result)
    printstyled(component_result.stats, "\n", color=:yellow)
    @test string(component_result.component.e) == expected_component
end
