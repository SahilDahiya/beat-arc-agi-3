using Test
using q23: ill_typed_production, subset_matches_to_production, Production, parse_exp, get_production, SubExp, drawing_grammar, drawing_corpus, ComponentSearchConfig, init_component, holetype, get_descendant, corpus_data, expand



@testset "q3b" begin
    grammar = drawing_grammar()
    println("Testing subset_matches_to_production")

    corpus, grammar = drawing_corpus()
    config = ComponentSearchConfig(grammar, false, 0)
    search = init_component(corpus, config, :cmd, Symbol("component1"))

    println("testing match locations during ?cmd -> (move ?angle ?num ?cmd)")
    production = get_production(grammar, :cmd, :move)
    hole = pop!(search.holes)
    original_matches = search.matches
    subset_matches_to_production(hole, original_matches, production, search)
    @test length(search.matches) < length(original_matches) # this should not be mutating `original_matches` in place

    # ensure that the matches have the correct head
    for match in search.matches
        descendant = get_descendant(match, hole.zipper)
        @test corpus_data(descendant).production.head === :move
        @test corpus_data(descendant).production.return_type === :cmd
    end

    # ensure that none of the other matches have the correct head
    for match in original_matches
        descendant = get_descendant(match, hole.zipper)
        if corpus_data(descendant).production.head === :move && corpus_data(descendant).production.return_type === :cmd
            @test !isnothing(findfirst(m -> m == match, search.matches))
        end
    end

    # test expand while we're at it, but this should still work fine if it worked back in problem 2!
    expand(hole, production, search)

    # Now lets apply a constant production to the ?num hole to test whether the data match is handled correctly
    println("testing match locations during (move ?angle ?num done) -> (move ?angle 3 ?cmd)")
    production = get_production(grammar, :num, :const; data=3)
    hole = search.holes[2] # normally during search we'd always pop the last hole, but this should work fine too
    original_matches = search.matches
    subset_matches_to_production(hole, original_matches, production, search)
    
    # ensure that the matches have the correct head and data
    for match in search.matches
        descendant = get_descendant(match, hole.zipper)
        @test corpus_data(descendant).production.head === :const
        @test corpus_data(descendant).production.return_type === :num
        @test corpus_data(descendant).production.data === 3
    end

    # ensure that none of the other matches have the correct head and data
    for match in original_matches
        descendant = get_descendant(match, hole.zipper)
        if corpus_data(descendant).production.head === :const && corpus_data(descendant).production.return_type === :num && corpus_data(descendant).production.data === 3
            @test !isnothing(findfirst(m -> m == match, search.matches))
        end
    end
end