using Test
using q23: drawing_tasks, parse_exp, drawing_grammar

@testset "internal" begin
    grammar = drawing_grammar()
    drawing_tasks()
    parse_exp("(foo bar (baz 5))")
    return nothing
end