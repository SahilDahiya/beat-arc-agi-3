using Test
using q23: drawing_tasks, drawing_grammar, solve_task

@testset "q2d" begin
    task = drawing_tasks()[1]
    is_correct = (e) -> false # don't actually execute the program
    grammar = drawing_grammar()
    kwargs = (max_weight=4.0, is_correct, grammar, verbose=true, disable_evaluation=true)
    println()
    println("Running search WITH type-based pruning")
    solve_task(task; kwargs..., disable_types=false)
    println()
    println("Running search WITHOUT type-based pruning")
    solve_task(task; kwargs..., disable_types=true)
    return nothing
end