import stitch_core
import json


with open("data/graphics.json", "r") as f:
    data = json.load(f)
    names = [task["name"] for task in data]
    programs = [task["program"] for task in data]

for (name, program) in zip(names, programs):
    print(f"{name}: {program}")
print()

# Add code that compresses the programs using stitch (3 iterations with a max arity of 3)
# and prints out the first 3 abstractions along and the rewritten programs.
# Add a comment naming or explaining each abstraction.
# YOUR CODE HERE


"""
Put the output of the code here (the abstractions and the rewritten programs):

# YOUR CODE HERE
"""

"""
Put your description of the abstractions here:

# YOUR CODE HERE

"""

