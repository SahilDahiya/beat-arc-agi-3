

"""
The configuration of an iterative deepening search. Iterative deepening searches through a series
of top-down searches each covering a different range of weights.
- `step_weight` is the weight of each step of the search.
- `top_down` is the configuration of the top-down search, and `min_weight` and `max_weight` are
  interpreted as the overall minimum and maximum weights for the search - we move in `step_weight` increments.
  from `min_weight` to `max_weight`.
"""
mutable struct IterativeDeepeningConfig
    step_weight::Float64
    verbose::Bool
    top_down::TopDownConfig
end
function Base.copy(config::IterativeDeepeningConfig)
    return IterativeDeepeningConfig(config.step_weight, config.verbose, copy(config.top_down))
end

function iterative_deepening_search(config::IterativeDeepeningConfig)
    # our goal is to perform a search in the weight range [global_min_weight, global_max_weight]
    # by iteratively searching in the range [min_weight, min_weight + step_weight] while increasing min_weight by step_weight
    # until we find a solution or min_weight reaches global_max_weight
    global_min_weight = config.top_down.min_weight
    global_max_weight = config.top_down.max_weight

    min_weight = global_min_weight
    stats = Stats(0, 0)

    result = TopDownSearchResult(nothing, Inf, stats)

    while min_weight < global_max_weight
        # search the range [max_weight, min_weight + step_weight]
        max_weight = min(min_weight + config.step_weight, global_max_weight)

        # make a copy of the config with the new weight range
        top_down_config = copy(config.top_down)
        top_down_config.min_weight = min_weight
        top_down_config.max_weight = max_weight

        # run the search within the weight range
        config.verbose && printstyled("Starting search in weight range [$min_weight, $max_weight]\n", color=:blue)
        root = new_hole(top_down_config.type)
        se = SubExp(root, holetype(root), Int[])
        search = TopDownSearch(root, 0.0, SubExp[se], top_down_config, result)
        top_down_search(search)
        if config.verbose
            if issuccess(result)
                printstyled("Solved $(result)\n", color=:green)
            else
                printstyled("Solution not found $(result.stats)\n", color=:yellow)
            end
        end

        # if we found a solution, return it
        if issuccess(result)
            return result
        end

        # update the min weight for the next iteration
        min_weight = max_weight
    end

    return result
end

function solve_all(tasks, grammar; max_weight=9.0, max_expansions=typemax(Int), threads=false)
    results = Vector{TopDownSearchResult}(undef, length(tasks))
    work_to_do = collect(enumerate(tasks))

    function do_work(i, task)
        result = solve_task(task; max_weight=max_weight, max_expansions=max_expansions, grammar=grammar)
        results[i] = result
        if issuccess(result)
            printstyled("Task $i: Solved $(task.name) $(result)\n", color=:green)
        else
            printstyled("Task $i: $(task.name) Failed when searching to weight=$max_weight $(result.stats)\n", color=:red)
        end
    end

    if threads
        Threads.@threads :greedy for (i, task) in work_to_do
            do_work(i, task)
        end
    else
        for (i, task) in work_to_do
            do_work(i, task)
        end
    end

    return results
end

function solve_task(task; max_weight=10.0, max_expansions=typemax(Int), grammar=drawing_grammar(), is_correct=drawing_correctness(task), verbose=false, disable_types=false, disable_evaluation=false)
    config = IterativeDeepeningConfig(1.0, verbose, TopDownConfig(grammar, is_correct, 0.0, max_weight, max_expansions, task.type, disable_types, disable_evaluation))
    return iterative_deepening_search(config)
end