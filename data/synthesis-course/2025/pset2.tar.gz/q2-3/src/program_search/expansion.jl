"""
Creates a new hole of the given type.
"""
function new_hole(type::Symbol)
    return Exp(HOLE_SYMBOL, type, Exp[], nothing)
end

"""
Applies a production to a hole to turn it into an expression with new holes as arguments.
"""
function expand_inner(e::Exp, production::Production)::Nothing
    @assert ishole(e)
    # YOUR CODE HERE
end

"""
This function should undo all the effects of `expand_inner`, modifying
    `e` in place to be a hole of the given type.
"""
function unexpand_inner(e::Exp, type::Symbol)::Nothing
    @assert !ishole(e)
    # YOUR CODE HERE
end


