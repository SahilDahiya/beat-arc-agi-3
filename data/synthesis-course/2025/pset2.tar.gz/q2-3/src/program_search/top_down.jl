"""
The configuration of a top-down search which won't expand further than programs of weight `max_weight`.
- `grammar` is the grammar of the language.
- `check_correctness` is a function returning true if the program solves the task.
- `min_weight` and `max_weight` give the range of program weights (ie sizes, roughly) to search over.
- `max_expansions` is the maximum number of expansions to perform.
- `type` is the type of the program to search for.
- `disable_types` is a boolean that, if true, will disable the check on the type of the program.
- `disable_evaluation` is a boolean that, if true, will disable the evaluation of the program.
"""
mutable struct TopDownConfig
    grammar::Grammar
    check_correctness::Function
    min_weight::Float64
    max_weight::Float64
    max_expansions::Int
    type::Symbol
    disable_types::Bool
    disable_evaluation::Bool
end

function Base.copy(config::TopDownConfig)
    return TopDownConfig(config.grammar, config.check_correctness, config.min_weight, config.max_weight, config.max_expansions, config.type, config.disable_types, config.disable_evaluation)
end

mutable struct Stats
    expansions::Int
    completions::Int
end

function Base.show(io::IO, stats::Stats)
    print(io, "expansions=$(stats.expansions) completions=$(stats.completions)")
end

mutable struct TopDownSearchResult
    solution::Union{Nothing, Exp}
    solution_weight::Float64
    stats::Stats
end

function Base.show(io::IO, result::TopDownSearchResult)
    print(io, "[weight=$(result.solution_weight) $(result.stats)] $(result.solution)")
end

function issuccess(result::TopDownSearchResult)
    return !isnothing(result.solution)
end

"""
A more direct search for a program when the expression for it is already given
"""
function search_for_program(body::Exp, grammar::Grammar, type::Symbol)
    init = new_hole(type)
    search = TopDownSearch(init, 0.0, [SubExp(init, holetype(init), Int[])], TopDownConfig(grammar, (_) -> false, 0.0, 10.0, typemax(Int), type, false, false), TopDownSearchResult(nothing, 0.0, Stats(0, 0)))
    while !isempty(search.holes)
        hole = pop!(search.holes)
        target = get_descendant(body, hole.zipper)
        production = production_of_expr(target, hole.type, grammar)
        expand(hole, production, search)
    end
    return search.e
end


"""
The state of a top-down search.
- `e` is the current expression. This starts as a single hole and is expanded/unexpanded in place
  to search over the space of programs.
- `weight` is the current weight (size) of the expression, which is the sum over the weights of the
  productions used to create the expression (most productions have weight 1.0).
- `holes` is the list of holes in `e` remaining to be expanded (initially this is just the root hole).
- `result` is the result of the search (keeps track of the best solution found so far also with search stats).
"""
mutable struct TopDownSearch
    e::Exp
    weight::Float64
    holes::Vector{SubExp}
    config::TopDownConfig
    result::TopDownSearchResult
end


function evaluate_solution(search::TopDownSearch)
    search.result.stats.completions += 1
    if search.config.disable_evaluation
        return
    end
    if search.config.check_correctness(search.e)
        if search.weight < search.result.solution_weight
            search.result.solution = copy(search.e)
            search.result.solution_weight = search.weight
            # printstyled("[expansions=$(search.stats.expansions) completed=$(search.stats.completions)] new best: $(search.result)\n", color=:green)
        end
    end
end

"""
Expands the hole `se` with the production `production`.
"""
function expand(se::SubExp, production::Production, search)::Nothing
    search.result.stats.expansions += 1
    # YOUR CODE HERE
    return nothing
end

"""
Undoes the effects of `expand`
"""
function unexpand(se::SubExp, production::Production, search)::Nothing
    # YOUR CODE HERE
    return nothing
end

"""
Performs a top-down search for a solution to the task.
"""
function top_down_search(search::TopDownSearch)
    # YOUR CODE HERE
    return search
end