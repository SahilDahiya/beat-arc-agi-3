for file in readdir("test")
    if contains(file, "dreamcoder")
        continue
    end
    include("../test/$file")
end