const HOLE_SYMBOL = :?
const VAR_SYMBOL = :$
const CONST_SYMBOL = :const

"""
An expression in a language.
- `head` is the first symbol of the expression, often an operator like `:/` or `+`.
- `data` is any head-specific data for the expression. This is usually `nothing` other than in a few special cases:
    - if the head is `:const`, data is the value of the constant (eg the integer `4`).
    - if the head is `:?` this is a hole, and data is the type of the hole.
    - a few other special cases (`:lib` and `:\$` are used in componentization)
- `args` is a vector of the arguments of the expression. For example `(/ 2 3)` has args `2` and `3`.
- `scratch` is a scratch space used by some algorithms.

Examples:
- The expression `(+ 2 3)` has head `:+`, data `nothing`, args `2` and `3`, and scratch `nothing`.
- The expression `?num` has head `:?`, data `:num`, args `[]`, and scratch `nothing`.
- The expression `2` has head `:const`, data `2`, args `[]`, and scratch `nothing`.
"""
mutable struct Exp
    head::Symbol
    data::Any
    args::Vector{Exp}
    scratch::Any
end

function Base.copy(e::Exp)
    return Exp(e.head, e.data, Exp[copy(arg) for arg in e.args], e.scratch)
end

function Base.:(==)(e1::Exp, e2::Exp)
    return e1.head === e2.head && e1.data == e2.data && e1.args == e2.args
end

function Base.show(io::IO, e::Exp)
    if ishole(e)
        print(io, "?", e.data) # hole shows as ?type
        return
    end

    if isvar(e)
        print(io, "\$", e.data.idx) # variable shows as $idx
        return
    end

    if e.head === CONST_SYMBOL
        print(io, e.data) # constants like 5 show as their inner value
        return
    end

    if e.head === :lib
        if isempty(e.args)
            print(io, "(#", e.data.name, ")") # library function with no arguments shows as #name
            return
        end
        print(io, "(#", e.data.name) # library function with arguments shows as (#name arg1 arg2 ...)
        for arg in e.args
            print(io, " ", arg)
        end
        print(io, ")")
        return
    end

    if isempty(e.args)
        print(io, e.head) # if there are no arguments, instead of printing "(head)" we print "head"
        return
    end

    print(io, "(", e.head)
    for arg in e.args
        print(io, " ", arg)
    end
    print(io, ")")
end


function isvar(e::Exp)
    return e.head === VAR_SYMBOL
end

function ishole(e::Exp)
    return e.head === HOLE_SYMBOL
end

function holetype(e::Exp)
    @assert ishole(e)
    return e.data
end

function sethole(e::Exp, type::Symbol)
    e.head = HOLE_SYMBOL
    e.data = type
    empty!(e.args)
    return e
end

"""
A subexpression (descendant) of an expression.
A SubExp contains a pointer to the subexpression, the type of the subexpression, and a zipper from the root of the expression to the subexpression.

A zipper is a path from the root of the expression to a descendant, represented as a vector of integers indicating the indices of the arguments to follow (see `get_descendant` for example usage).

Important: `e` is the subexpression itself (at the end of the zipper), not the root expression.
"""
struct SubExp
    e::Exp # the subexpression itself
    type::Symbol # the type of the subexpression
    zipper::Vector{Int} # the zipper from the root of an expression to the subexpression
end

"""
Applies a zipper to an expression to get the descendant at the end of the zipper. A zipper is a path
from the root of the expression to a descendant, represented as a vector of integers
where each integer is the index of an argument of the expression.
"""
function get_descendant(e, zipper::Vector{Int})
    for i in zipper
        e = e.args[i]
    end
    return e
end

function set_copy(dst::Exp, src::Exp)
    dst.head = src.head
    dst.data = src.data
    empty!(dst.args)
    for arg in src.args
        push!(dst.args, copy(arg))
    end
end

"""
Vars are used in componentization
"""
struct Var
    idx::Int
    fresh::Bool
end

function Base.:(==)(v1::Var, v2::Var)
    return v1.idx == v2.idx # we dont enforce fresh/reused distinction because parsing erases it
end

"""
Creates a new variable of the given index, assumed to be fresh (i.e. the first usage of this variable in the component)
"""
function fresh_var(idx::Int)
    return Exp(VAR_SYMBOL, Var(idx, true), Exp[], nothing)
end

"""
Creates a new variable of the given index, assumed to be reused (i.e. the variable has already been used in the component)
"""
function reused_var(idx::Int)
    return Exp(VAR_SYMBOL, Var(idx, false), Exp[], nothing)
end

"""
Mutate an expression in-place to be a variable.
"""
function set_var(e::Exp, var::Var)
    e.head = VAR_SYMBOL
    e.data = var
    empty!(e.args)
end

