function parse_exp(s::String)
    e, offset = parse_exp(s, 1)
    offset <= length(s) && error("trailing characters")
    return e
end

function parse_exp(s::String, offset::Int)
    offset > length(s) && error("unexpected end of input")
    token = s[offset]
    token == ')' && error("unmatched close parenthesis")
    
    if token == '('
        offset += 1 # skip open paren
        head, offset = parse_head(s, offset)
        args = []
        while true
            offset > length(s) && error("unmatched open parenthesis for head $head in $s at offset $offset")
            s[offset] == ')' && break
            arg, offset = parse_exp(s, offset)
            push!(args, arg)
        end
        offset += 1 # skip close paren
        offset = skip_whitespace(s, offset)
        return Exp(Symbol(head), nothing, args, nothing), offset
    elseif isdigit(token) || (token == '-' && length(s) > offset && isdigit(s[offset+1]))
        number, offset = parse_number(s, offset)
        return Exp(CONST_SYMBOL, number, [], nothing), offset
    elseif token == '?'
        offset += 1
        type, offset = parse_head(s, offset)
        return Exp(HOLE_SYMBOL, Symbol(type), [], nothing), offset
    elseif token == '$'
        offset += 1
        name, offset = parse_number(s, offset)
        return Exp(VAR_SYMBOL, Var(name, true), [], nothing), offset
    elseif !reserved_symbol(token)
        # (foo bar baz) gets parsed as (foo (bar) (baz))
        head, offset = parse_head(s, offset)
        return Exp(Symbol(head), nothing, [], nothing), offset
    end
    error("expected open paren, got $token")
end

function parse_head(s::String, offset::Int)
    head, offset = takewhile(s, offset, c -> !reserved_symbol(c))
    @assert !isempty(head)
    offset = skip_whitespace(s, offset)
    return head, offset
end

function parse_number(s::String, offset::Int)
    neg = s[offset] == '-'
    if neg
        offset += 1
    end
    num, offset = takewhile(s, offset, c -> isdigit(c) || c == '.')
    offset = skip_whitespace(s, offset)
    if '.' in num
        return parse(Float64, num) * (neg ? -1 : 1), offset
    else
        return parse(Int, num) * (neg ? -1 : 1), offset
    end
end

function reserved_symbol(c)
    return c == ' ' || c == '(' || c == ')'
end

function skip_whitespace(s::String, offset::Int)
    return takewhile(s, offset, c -> c == ' ')[2]
end

function takewhile(s::String, offset::Int, f::Function)
    offset > length(s) && return "", offset
    offset_end = offset - 1
    while offset_end + 1 <= length(s) && f(s[offset_end+1])
        offset_end += 1
    end
    return s[offset:offset_end], offset_end + 1
end