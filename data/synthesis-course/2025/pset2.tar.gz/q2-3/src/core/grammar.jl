
"""
A production rule for the grammar. (+ ?num ?num)
- `head` and `data`
- `arg_types` is a vector of the types of the arguments of the production.
- `return_type` is the type of the expression produced by the production. The production can only be applied to expand holes of this type.
- `weight` is how much the production contributes to the weight (i.e. size) of an expression it's part of (usually 1.0).

Examples:
- The production used to expand ?num -> (+ ?num ?num) has head=+, data=nothing, arg_types=[:num, :num], return_type=:num, weight=1.0.
- The production for expanding ?num -> 2 has head=:const, data=2, arg_types=[], return_type=:num, weight=1.0.
"""
mutable struct Production
    head::Symbol
    data::Any
    arg_types::Vector{Symbol}
    return_type::Symbol
    weight::Float64
end
function Production(return_type::Symbol, e; weight=1.)
    if e isa String
        e = parse_exp(e)
    end
    for arg in e.args
        @assert ishole(arg) "Production must be an expression where all children are holes"
    end
    arg_types = [holetype(arg) for arg in e.args]
    Production(e.head, e.data, arg_types, return_type, weight)
end

function Base.:(==)(p1::Production, p2::Production)
    return p1.head === p2.head && p1.data == p2.data && p1.arg_types == p2.arg_types && p1.return_type == p2.return_type
end

"""
A grammar is simply a collection of production rules. We assume that each (production.return_type, production.head, production.data) triple is unique.
"""
mutable struct Grammar
    productions::Vector{Production}
end

function Base.show(io::IO, g::Grammar)
    for p in g.productions
        println(io, p)
    end
end

"""
Returns true if the expression `e` could be produced by the production `p`.
"""
function unifies(e::Exp, p::Production)
    @assert !ishole(e)
    return e.head === p.head && e.data == p.data
end

function isvar(p::Production)
    return p.head === VAR_SYMBOL
end

function get_production(grammar::Grammar, type::Symbol, head::Symbol; data=nothing)
    idx = findfirst(p -> p.return_type == type && p.head == head && p.data == data, grammar.productions)
    if isnothing(idx)
        error("Production not found: $head of type $type")
    end
    return grammar.productions[idx]
end

"""
Creates a simple grammar that is untyped (all types are :any) but includes all productions necessary
to generate the given programs. Used for the nuts-bolts domain.
"""
function naive_grammar(programs::Vector{Exp})
    productions = Production[]
    type = :any
    worklist = copy(programs)
    while !isempty(worklist)
        node = pop!(worklist)
        for arg in node.args
            push!(worklist, arg)
        end

        head = node.head
        data = node.data
        arg_types = [type for _ in node.args]
        
        production = findfirst(p -> p.head == head && p.data == data, productions)
        if isnothing(production)
            production = Production(head, data, arg_types, type, 1.0)
            push!(productions, production)
        else
            @assert productions[production].arg_types == arg_types
        end
    end
    sort!(productions, by=p -> (p.head, p.data))
    return Grammar(productions)
end