module q23

using OrderedCollections
using JSON

include("core/exp.jl")
include("core/parsing.jl")
include("core/grammar.jl")

include("program_search/expansion.jl")
include("program_search/top_down.jl")
include("program_search/iterative_deepening.jl")

include("component_search/corpus.jl")
include("component_search/branch_and_bound.jl")
include("component_search/vars.jl")
include("component_search/rewriting.jl")

include("drawing_domain/drawing_eval.jl")
include("drawing_domain/drawing_grammar.jl")
include("drawing_domain/drawing_tasks.jl")

end
