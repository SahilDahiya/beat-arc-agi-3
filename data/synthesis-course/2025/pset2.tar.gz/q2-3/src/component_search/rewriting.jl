
function production_of_component(component::Component)
    return Production(:lib, component, [arg.type for arg in component.fresh_args], component.type, 1.0)
end

function add_production(grammar::Grammar, production::Production)
    push!(grammar.productions, production)
end

function set_rewritten_at_matches(matches::Vector{Exp}, component::Component, production::Production)
    for match in matches
        args = [get_descendant(match, arg.zipper) for arg in component.fresh_args]
        rewritten = Exp(production.head, production.data, args, CorpusData(production))
        corpus_data(match).rewritten = rewritten
    end
end


function rewrite_corpus(corpus::Corpus, matches::Vector{Exp}, component::Component, lib_production::Production)
    set_rewritten_at_matches(matches, component, lib_production)
    foreach_bottom_up(update_weights_with_rewritten, corpus)
    rewrite_at_matches(matches)
    return corpus
end


"""
Sets .total_weight to the minimum of the total weight of the expression and the total weight of the rewritten expression.
"""
function update_weights_with_rewritten(e::Exp)
    update_weight(e)
    if has_rewritten(e)
        rewritten = get_rewritten(e)
        update_weight(rewritten)
        if total_weight(rewritten) < total_weight(e)
            corpus_data(e).total_weight = total_weight(rewritten)
        end
    end
end

"""
Rewrites all the matches that where the rewritten expression is equal weight.
This is done after update_weights_with_rewritten() so if they're equal we know the rewrite is better (or equal)
"""
function rewrite_at_matches(matches::Vector{Exp})
    for match in matches
        rewritten = get_rewritten(match)
        if total_weight(rewritten) == total_weight(match)
            rewrite_at_match(match)
        end
        corpus_data(match).rewritten = nothing
    end
end

"""
Replaces the expression with its rewritten version.
"""
function rewrite_at_match(e::Exp)
    rewritten = get_rewritten(e)
    e.head = rewritten.head
    e.data = rewritten.data
    e.args = rewritten.args
    e.scratch = rewritten.scratch
end