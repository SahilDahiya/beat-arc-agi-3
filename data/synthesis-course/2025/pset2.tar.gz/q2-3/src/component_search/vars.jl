
"""
[Do Not Edit]
We keep track of fresh and reused variables in `fresh_args` and `reused_args` respectively.
"""
function expand(se::SubExp, var::Var, search::ComponentSearch)::Nothing
    search.result.stats.expansions += 1
    vars = var.fresh ? search.component.fresh_args : search.component.reused_args
    push!(vars, se)
    set_var(se.e, var)
    return nothing
end

"""
[Do Not Edit]
"""
function unexpand(se::SubExp, var::Var, search::ComponentSearch)::Nothing
    vars = var.fresh ? search.component.fresh_args : search.component.reused_args
    pop!(vars)
    unexpand_inner(se.e, se.type)
    return nothing
end

"""
[Do Not Edit]
Variables work regardless of the type
"""
function ill_typed_production(production::Var, hole::SubExp)
    return false
end

"""
[Do Not Edit]
Don't worry about handling the Vars that this function returns - that is handled by our Var versions of `ill_typed_production`, `subset_matches_to_production`, `expand`, and `unexpand`.
"""
function possible_productions(search::ComponentSearch)
    if search.config.max_arity == 0
        return search.config.grammar.productions
    end
    return Iterators.flatten([search.config.grammar.productions, possible_vars(search)])
end

"""
[Do Not Edit]
Fresh (as is first-time-used) variables are allowed up until the max arity is reached.
Reused variables (for example in (+ \$1 \$1)) are always allowed.
"""
function possible_vars(search::ComponentSearch)
    vars = Var[]

    for se in search.component.fresh_args
        push!(vars, Var(se.e.data.idx, false))
    end
    if length(search.component.fresh_args) < search.config.max_arity
        push!(vars, Var(length(search.component.fresh_args)+1, true))
    end
    return vars
end

"""
[Do Not Edit]
Fresh (as is first-time-used) variables doesn't constrain matches at all - much like a hole, a variable can match at any location.
Existing variables (for example in (+ \$1 \$1)) constrain matches to the subset of match locations that have the same expression at the fresh and reused locations of the variable.
"""
function subset_matches_to_production(hole::SubExp, matches::Vector{Exp}, var::Var, search::ComponentSearch)::Nothing
    if var.fresh
        search.matches = matches
        return nothing
    end
    # introducing a reused arg
    existing_arg = search.component.fresh_args[var.idx]
    search.matches = filter(matches) do match
        descendant1 = get_descendant(match, hole.zipper)
        descendant2 = get_descendant(match, existing_arg.zipper)
        descendant1 == descendant2
    end
    return nothing
end

