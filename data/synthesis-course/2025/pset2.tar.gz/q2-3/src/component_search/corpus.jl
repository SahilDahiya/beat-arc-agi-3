

mutable struct CorpusData
    production::Production
    total_weight::Float64
    rewritten::Union{Nothing, Exp}
    function CorpusData(production::Production)
        return new(production, 0.0, nothing)
    end
end

@inline function corpus_data(e::Exp)::CorpusData
    return e.scratch
end

function production(e::Exp)
    return corpus_data(e).production
end

function total_weight(e::Exp)
    return corpus_data(e).total_weight
end

function set_total_weight(e::Exp, total_weight)
    corpus_data(e).total_weight = total_weight
end


function get_rewritten(e::Exp)::Exp
    return corpus_data(e).rewritten
end

function has_rewritten(e::Exp)
    return !isnothing(corpus_data(e).rewritten)
end

mutable struct Corpus
    roots::Vector{Exp}
    bottom_up_orders::Vector{Vector{Exp}}
    names::Vector{String}

    function Corpus(roots::Vector{Exp}, types::Vector{Symbol}, names::Vector{String}, grammar::Grammar)
        bottom_up_orders = bottom_up_order.(roots)
        for (root, type) in zip(roots, types)
            set_corpus_data(root, type, grammar)
        end
        corpus = new(roots, bottom_up_orders, names)
        foreach_bottom_up(update_weight, corpus)
        return corpus
    end
end

function Base.show(io::IO, corpus::Corpus)
    for (i, root) in enumerate(corpus.roots)
        println(io, corpus.names[i], ": ", root)
    end
end

function total_weight(corpus::Corpus)
    return sum(corpus_data(root).total_weight for root in corpus.roots; init=0.)
end

function production_of_expr(e::Exp, type::Symbol, grammar::Grammar)
    idx = findfirst(p -> p.return_type == type && unifies(e, p), grammar.productions)
    @assert !isnothing(idx) "Production not found for $e of type $type"
    idx2 = findnext(p -> p.return_type == type && unifies(e, p), grammar.productions, idx+1)
    @assert isnothing(idx2)
    return grammar.productions[idx]
end


"""
Bottom-up descendants of an expression. In a breadth-first instead of depth-first
ordering though, which is less memory efficient for a lot of cases but easier to implement.
"""
function bottom_up_order(e::Exp)
    order = Exp[e]
    idx = 1
    while idx <= length(order)
        @inbounds e = order[idx]
        for arg in e.args
            push!(order, arg)
        end
        idx += 1
    end
    return reverse!(order)
end

function clear_scratch(e::Exp)
    e.scratch = nothing
end


function set_corpus_data(e::Exp, type::Symbol, grammar::Grammar)
    worklist = Tuple{Exp, Symbol}[(e, type)]
    while !isempty(worklist)
        e, type = pop!(worklist)
        production = production_of_expr(e, type, grammar)
        @assert length(e.args) == length(production.arg_types)    
        for (arg, type) in zip(e.args, production.arg_types)
            push!(worklist, (arg, type))
        end
        e.scratch = CorpusData(production)
    end
end

function update_weight(e::Exp)
    corpus_data(e).total_weight = corpus_data(e).production.weight + sum(corpus_data(arg).total_weight for arg in e.args; init=0.)
end

function foreach_bottom_up(f::F, corpus::Corpus) where F <: Function
    for order in corpus.bottom_up_orders
        for e in order
            f(e)
        end
    end
end
