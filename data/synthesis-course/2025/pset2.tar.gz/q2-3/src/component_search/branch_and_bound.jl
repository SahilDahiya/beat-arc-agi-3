"""
A component found in branch-and-bound search.
- `e` is the expression representing the component, for example `(repeat \$2 (move (/ tau \$2) \$1 done) done)`
- `fresh_args` and `reused_args` don't need to be touched for this problem set, they're handled by provided code (see `vars.jl`)
- `type` is the type of the component.
- `name` is the name of the component.
"""
mutable struct Component
    e::Exp
    fresh_args::Vector{SubExp}
    reused_args::Vector{SubExp}
    type::Symbol
    name::Symbol
end

function Base.show(io::IO, component::Component)
    print(io, component.e)
end

"""
Safely copies a component while maintaining internal references to the same subexpressions.
"""
function Base.copy(component::Component)
    e = copy(component.e)
    fresh_args = [SubExp(get_descendant(e, arg.zipper), arg.type, arg.zipper) for arg in component.fresh_args]
    reused_args = [SubExp(get_descendant(e, arg.zipper), arg.type, arg.zipper) for arg in component.reused_args]
    return Component(e, fresh_args, reused_args, component.type, component.name)
end

mutable struct ComponentSearchResult
    component::Component
    matches::Vector{Exp}
    weight::Float64
    utility::Float64
    stats::Stats
end

function Base.show(io::IO, result::ComponentSearchResult)
    print(io," [weight=$(result.weight) matches=$(length(result.matches)) utility=$(result.utility)] $(result.component)")
end

"""
The configuration of a component search.
- `grammar` is the grammar of the language.
- `disable_pruning` turns of branch-and-bound pruning (and other forms of pruning)
- `max_arity` is the maximum number of (fresh) arguments the component to search for can have.
"""
struct ComponentSearchConfig
    grammar::Grammar
    disable_pruning::Bool
    max_arity::Int
end

"""
The state of a search for components.
- `component` is the current component being searched for and it mutated in place.
- `holes` is the list of holes remaining to be expanded.
- `matches` is the current list of places in the corpus that the component matches at.
- `weight` is the weight of the component.
- `corpus` is the corpus of programs being searched over.
- `result` is the best result found so far, used for upper-bound pruning and returned at the end.
- `config` has some settings for the search.
"""
mutable struct ComponentSearch
    component::Component
    holes::Vector{SubExp}
    matches::Vector{Exp}
    weight::Float64
    corpus::Corpus
    result::ComponentSearchResult
    config::ComponentSearchConfig
end

function Base.show(io::IO, search::ComponentSearch)
    print(io, search.component.e, " [w=$(search.weight) x m=$(length(search.matches)) ub=$(upper_bound(search.matches))]")
end

"""
Evaluates the component and updates the best result if it's better.
"""
function evaluate_component(search::ComponentSearch)
    search.result.stats.completions += 1
    util = utility(search)
    if util > search.result.utility
        search.result.utility = util
        search.result.matches = copy(search.matches)
        search.result.weight = search.weight
        search.result.component = copy(search.component)
        # printstyled("[expansions=$(search.result.stats.expansions) completed=$(search.result.stats.completions)] new best: $(search.result)\n", color=:green)
    end
end

"""
Searches for a component and rewrites the corpus to use the new component
"""
function find_component_and_rewrite(corpus::Corpus, config::ComponentSearchConfig, name::Symbol)
    component_result = find_component(corpus, config, name)
    isnothing(component_result) && return nothing
    lib_production = production_of_component(component_result.component)
    add_production(config.grammar, lib_production)
    rewrite_corpus(corpus, component_result.matches, component_result.component, lib_production)
    return component_result
end

"""
Finds a component through a series of searches, one for each type the component could have.
"""
function find_component(corpus::Corpus, config::ComponentSearchConfig, name::Symbol)
    possible_types = sort!(collect(Set([production.return_type for production in config.grammar.productions])))
    best_result = nothing
    for abstraction_type in possible_types
        # search for abstractions of type abstraction_type
        search = init_component(corpus, config, abstraction_type, name)
        if !isnothing(best_result)
            search.result = best_result
        end
        res = branch_and_bound(search)
        if isnothing(best_result) || res.result.utility > best_result.utility
            best_result = res.result
        end
    end
    if best_result.utility <= 0
        return nothing
    end
    return best_result
end

"""
Initializes the ComponentSearch struct for use in branch-and-bound search.
"""
function init_component(corpus::Corpus, config::ComponentSearchConfig, abstraction_type::Symbol, name::Symbol)
    e = new_hole(abstraction_type)
    matches = vcat(corpus.bottom_up_orders...)
    filter!(matches) do match
        corpus_data(match).production.return_type == abstraction_type
    end
    hole = SubExp(e, holetype(e), Int[])
    component = Component(e, [], [], abstraction_type, name)
    best_so_far = ComponentSearchResult(copy(component), copy(matches), 0., -Inf, Stats(0, 0))
    return ComponentSearch(component, [hole], matches, 0., corpus, best_so_far, config)
end

"""
Returns true if the component has a fresh argument that is always the same value in all matches.
"""
function prune_useless_arg(search::ComponentSearch)
    for arg in search.component.fresh_args
        first_value = get_descendant(search.matches[1], arg.zipper)
        if all(match -> get_descendant(match, arg.zipper) == first_value, search.matches)
            return true
        end
    end
    return false
end

"""
Calculates the utility of a component. Equivalent to the change in corpus weight from rewriting with the component.
"""
function utility(search::ComponentSearch)
    per_match_utility = sum(search.matches; init=0.) do match
        # for each match, we get to delete the weight of the component itself
        base_utility = search.weight
        # but we have to introduce a new production with weight 1.0 which is the new component
        new_production_utility = -1.0
        # we add a small penalty for each fresh argument to discourage pointless arguments
        application_utility = -0.01 * length(search.component.fresh_args)
        # when a component uses an argument in multiple places, we get to delete the weight of the argument once for each place
        # other than the first one (the fresh one).
        reuse_utility = sum(search.component.reused_args; init=0.) do arg
            corpus_data(get_descendant(match, arg.zipper)).total_weight
        end
        return base_utility + new_production_utility + reuse_utility + application_utility
    end

    library_utility = -search.weight

    return per_match_utility + library_utility
end

"""
Calculates the upper bound of the possible utility of a set of matches.
"""
function upper_bound(matches::Vector{Exp})::Float64
    # YOUR CODE HERE
end

"""
Checks if any form of branch-and-bound pruning can be applied.
"""
function prune_search(search::ComponentSearch)
    if isempty(search.matches)
        return true
    end
    if search.config.disable_pruning
        return false
    end

    # YOUR CODE HERE
    return false
end

"""
Filters down the set of matches to only include those that could have come from the production: i.e. the head and data match.
"""
function subset_matches_to_production(hole::SubExp, matches::Vector{Exp}, production::Production, search::ComponentSearch)::Nothing
    # YOUR CODE HERE
end

function ill_typed_production(production::Production, hole::SubExp)
    return production.return_type != hole.type
end

function branch_and_bound(search::ComponentSearch)
    # YOUR CODE HERE
    return search
end
