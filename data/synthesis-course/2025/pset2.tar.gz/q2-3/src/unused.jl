"""
A more direct search for a component when the expression for it is already given – just finds all the matches and such
"""
function search_for_component(body::Exp, corpus::Corpus, grammar::Grammar, abstraction_type::Symbol, name::Symbol)
    search = init_component(corpus, grammar, abstraction_type, name)
    while !isempty(search.holes)
        hole = pop!(search.holes)
        target = get_descendant(body, hole.zipper)
        if isvar(target)
            if target.data.idx > length(search.component.fresh_args)
                production = Production(hole.type, fresh_var(target.data.idx); weight=0.0)
            else
                production = Production(hole.type, reused_var(target.data.idx); weight=0.0)
            end
        else
            production = production_of_expr(target, hole.type, grammar)
        end
        subset_matches_to_production(hole, search.matches, production, search)
        expand(hole, production, search)
    end
    return search
end