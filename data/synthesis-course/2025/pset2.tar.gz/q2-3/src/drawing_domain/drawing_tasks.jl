function drawing_tasks()
    tasks = DrawingTask[
        make_task("Line", "(move tau 1 done)"),
        # make_task("Dashed Line", "(repeat 4 (move tau 1 (penup (move tau 1 done) done)) done)"),
        make_task("Circle", circle()),
        # make_task("LineToCircle", "(move tau 3 $(circle()))"),
        make_task("Triangle", uncentered_ngon(3, 4)),
        make_task("Pentagon", uncentered_ngon(5, 2)),
        make_task("Hexagon", uncentered_ngon(6, 3)),
        make_task("Rotated & Translated Square", "(penup (move (/ tau 3) 2 done) $(uncentered_ngon(4, 3)))"),
        make_task("Chain Squares", "$(chain(3, uncentered_ngon(4, 3)))"),
        make_task("Chain Pentagons", "$(chain(3, uncentered_ngon(5, 3)))"),

        make_task("Rotationally Symmetric Squares", rotational_symmetry(5, 4, uncentered_ngon(4, 2))),
        make_task("Rotationally Symmetric Pentagons", rotational_symmetry(6, 4, uncentered_ngon(5, 2))),
        make_task("Rotationally Symmetric Circles", rotational_symmetry(6, 4, circle())),
        # make_task("Rotationally Symmetric Lines", rotational_symmetry(5, 4, "(move tau 2 done)")),


        # make_task("House", "$(uncentered_ngon(4, 2))"),
        # make_task("Centered Triangle", ngon(3, 2)),
        # make_task("Centered Square", ngon(4, 2)),
        # make_task("Centered Pentagon", ngon(5, 1)),
        # make_task("Centered Hexagon", ngon(6, 1)),
        # make_task("Circle", circle(6)),
        # "Semicircle" => make_task("Semicircle", semicircle(8)),
        # "Two Rings" => make_task("Two Rings", "(& $(circle(8)) (& (move 1) $(circle(8))))"),
        # "Three Rings" => make_task("Three Rings", "(& $(circle(2)) (& (move (/ 1 2)) (& $(circle(4)) (& (move 1) $(circle(8))))))"),
        # "Ring of Rings" => make_task("Ring of Rings", rotational_symmetry(5, 2, circle(3))),
        # "Overlapping Ring of Rings" => make_task("Overlapping Ring of Rings", rotational_symmetry(5, 2, circle(8))),

    ]

    write_out("data/graphics.json", simplify.(tasks); indent=2)
    if isdir("../../../../WebContent")
        println("Writing to pset2view.json")
        write_out("../../../../WebContent/pset2_content/pset2view.json", tasks)
    end
    

    # ensure tasks are solvable
    grammar = drawing_grammar()
    for task in tasks
        search_for_program(parse_exp(task.program), grammar, task.type)
    end


    return tasks
end

function simplify(task)
    return (
        name = task.name,
        program = task.program,
        type = task.type
    )
end

struct DrawingTask
    name::String
    program::Union{String, Nothing}
    canvas::Canvas # solution canvas
    high_res_canvas::Canvas # higher resolution display canvas
    type::Symbol
end
function Base.show(io::IO, task::DrawingTask)
    print(io, "DrawingTask(name=$(task.name), program=$(task.program), type=$(task.type))")
end

function make_task(name, program)
    high_res_canvas = execute(program, State(;canvas=Canvas(;resolution=128))).canvas
    canvas = execute(program).canvas
    return DrawingTask(name, program, canvas, high_res_canvas, :cmd)
end

function drawing_correctness(example::DrawingTask)
    canvas = Canvas()
    function is_correct(e)
        reset!(canvas)
        state = State(;canvas=canvas)
        res = execute(e, state).canvas.canvas
        return res == example.canvas.canvas
    end
    return is_correct
end

function drawing_corpus()
    grammar = drawing_grammar()
    corpus = open("data/graphics.json", "r") do f
        data = JSON.parse(f)
        programs = [parse_exp(task["program"]) for task in data]
        types = [Symbol(task["type"]) for task in data]
        names = [task["name"] for task in data]
        return Corpus(programs, types, names, grammar)
    end
    return corpus, grammar
end

uncentered_ngon(n, l) = "(repeat $n (move (/ tau $n) $l done) done)"
# rotational_symmetry(n, l, body) = "(repeat $n (move (/ tau $n) $l $body) done)"
rotational_symmetry(n, l, body) = "(repeat $n (penup (move (/ tau $n) $l done) $body) done)"
# rotational_symmetry_ngon(n, l) = "(repeat $n (penup (move (/ tau $n) $l done) $(uncentered_ngon(n, l))) done)"
circle() = uncentered_ngon("inf", "(* eps 6)")
chain(n, body) = "(repeat $n (penup (move tau $n done) $body) done)"