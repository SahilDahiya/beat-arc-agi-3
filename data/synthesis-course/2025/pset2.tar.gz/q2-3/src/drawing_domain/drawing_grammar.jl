function drawing_grammar()
    productions = [
        Production(:cmd, "(move ?angle ?num ?cmd)"), # Production for the expansion ?cmd -> (move ?angle ?num ?cmd). Turns by ?angle radians and moves by ?num units, then runs ?cmd.
        Production(:cmd, "(penup ?cmd ?cmd)"), # raises the pen (so that it doesnt draw), executes the first cmd, then lowers the pen and executes the second cmd
        Production(:cmd, "(repeat ?num ?cmd ?cmd)"), # runs the first cmd n times, then runs the second cmd
        Production(:cmd, "done"; weight=0.0), # does nothing. This is zero-weight (it doesn't contribute to the measured size of an expression)
        Production(:angle, "tau"; weight=0.0), # 2 pi radians (zero-weight)
        Production(:angle, "(/ ?angle ?num)"), # allows for angles like 2 pi / 3
        Production(:num, "(neg ?num)"), # negative constants
        Production(:num, "1"), # numeric constants like this get parsed as Exp(:const, 1, [], nothing)
        Production(:num, "2"),
        Production(:num, "3"),
        Production(:num, "4"),
        Production(:num, "5"),
        Production(:num, "6"),
        Production(:num, "inf"), # huge constant – useful for drawing circles (equal to 20 in practice)
        Production(:num, "(* ?epsilon ?num)"), # tiny constants – useful for drawing circles
        Production(:epsilon, "eps"; weight=0.0), # the epsilon constant (equal to 1/20 in practice) (zero-weight)
    ]

    return Grammar(productions)
end
