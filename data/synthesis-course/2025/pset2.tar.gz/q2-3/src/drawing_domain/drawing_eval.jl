

mutable struct Canvas
    canvas::Matrix{Int}
    size::Int
    resolution::Int
    step::Int
    function Canvas(;resolution=64, size=16)
        return new(zeros(Int, resolution, resolution), size, resolution, 0)
    end
end

function reset!(canvas::Canvas)
    canvas.step = 0
    fill!(canvas.canvas, 0)
    return canvas
end

mutable struct State
    x::Float64
    y::Float64
    angle::Float64
    penup::Bool
    canvas::Canvas
    function State(;canvas=Canvas(), x=canvas.size/2, y=canvas.size/2, angle=0.0, penup=false)
        return new(x, y, angle, penup, canvas)
    end
end

INF = 20
EPS = 1/INF

function execute(e::Exp; state = State())
    return execute(e, state)
end

function execute(e::String; state = State())
    return execute(parse_exp(e), state)
end

function execute(e::String, state)
    return execute(parse_exp(e), state)
end

function execute(e::Exp, state)
    if e.head === :&
        execute(e.args[1], state)
        execute(e.args[2], state)
        return state
    elseif e.head === :program
        return execute(e.args[1], state)
    elseif e.head === :id
        return execute(e.args[1], state)
    elseif e.head === :lib
        # inline the component into the expression
        component = copy(e.data)
        for arg in Iterators.flatten([component.fresh_args, component.reused_args])
            set_copy(arg.e, e.args[arg.e.data.idx])
        end
        return execute(component.e, state)
    elseif e.head === CONST_SYMBOL
        return e.data
    elseif e.head === :inf
        return INF
    elseif e.head === :eps
        return EPS
    elseif e.head === :tau
        return 2 * pi
    elseif e.head === :done
        return state
    elseif e.head === :penup
        old_penup = state.penup
        state.penup = true
        execute(e.args[1], state)
        state.penup = old_penup
        return execute(e.args[2], state) # continuation
    elseif e.head === :sin
        return sin(execute(e.args[1], state))
    elseif e.head === :+
        return execute(e.args[1], state) + execute(e.args[2], state)
    elseif e.head === :-
        return execute(e.args[1], state) - execute(e.args[2], state)
    elseif e.head === :*
        return execute(e.args[1], state) * execute(e.args[2], state)
    elseif e.head === :/
        return execute(e.args[1], state) / execute(e.args[2], state)
    elseif e.head === :neg
        return -execute(e.args[1], state)
    elseif e.head === :move
        # rotate by dtheta and then move by distance
        dtheta = execute(e.args[1], state)
        distance = execute(e.args[2], state)
        turn(state, dtheta)
        start_x, start_y = state.x, state.y
        move(state, distance)
        if !state.penup
            draw_line(state.canvas, start_x, start_y, state.x, state.y)
        end
        return execute(e.args[3], state) # continuation
    elseif e.head === :reset
        # run a command list and then reset the state to the initial state
        old_x, old_y, old_angle = state.x, state.y, state.angle
        execute(e.args[1], state)
        state.x, state.y, state.angle = old_x, old_y, old_angle
        return execute(e.args[2], state) # continuation
    elseif e.head === :repeat
        # run a command list n times
        n = execute(e.args[1], state)
        for _ in 1:n
            execute(e.args[2], state)
        end
        return execute(e.args[3], state) # continuation
    else
        error("Unknown head: $(e.head)")
    end
    error("Unreachable")
end

function move(state, distance)
    state.x += distance * cos(state.angle)
    state.y -= distance * sin(state.angle) # flip y since top left is (0, 0)
    return state
end

function turn(state, dtheta)
    state.angle += dtheta
    return state
end


"""
Draw a line between (x1, y1) and (x2, y2) on the canvas
The canvas is a matrix of ints, where 1 means the pixel is filled and 0 means the pixel is empty
In terms of the input x y coordinates, the top left is (0, 0) and bottom right is (size, size)
"""
function draw_line(canvas, x1, y1, x2, y2)
    px1, py1 = pixel_of_coordinate(canvas, x1, y1)
    px2, py2 = pixel_of_coordinate(canvas, x2, y2)

    # interpolate between the two pixels
    prev_x, prev_y = nothing, nothing
    for t in 0:0.01:1
        px = px1 * (1 - t) + px2 * t
        py = py1 * (1 - t) + py2 * t
        rounded_px = round(Int, px)
        rounded_py = round(Int, py)

        if prev_x == rounded_px && prev_y == rounded_py
            continue # same pixel was drawn on previous step
        end
        canvas.step += 1
        prev_x, prev_y = rounded_px, rounded_py

        (rounded_px < 1 || rounded_px > canvas.resolution || rounded_py < 1 || rounded_py > canvas.resolution) && continue
        canvas.canvas[rounded_px, rounded_py] = canvas.step
    end

    return canvas
end

function pixel_of_coordinate(canvas, x, y)
    px = x * canvas.resolution / canvas.size
    py = y * canvas.resolution / canvas.size
    return px, py
end

function write_out(file, state; indent=nothing)
    open(file, "w") do f
        json = isnothing(indent) ? JSON.json(state) : JSON.json(state, indent)
        write(f, json)
    end
    return
end
