# You can modify the imports if you'd like
import random
from env.state import ProofState, Value
from env.interaction import Trajectory, step
from env.actions import ACTION_SPACE
from q1a import Agent as Agent1a

# You aren't required to inherit from the earlier agent, but it may save you some work.
class Agent(Agent1a):
    # YOUR CODE HERE
    pass