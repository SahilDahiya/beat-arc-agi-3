import argparse
import importlib
import random
from env.parser import parse_theorem_signature
from env.interaction import Trajectory

from q1a import Agent as Agent1a
from q1b import Agent as Agent1b
from q1c import Agent as Agent1c
from q1d import Agent as Agent1d
from q1e import Agent as Agent1e

agents = {
    "1a": Agent1a,
    "1b": Agent1b,
    "1c": Agent1c,
    "1d": Agent1d,
    "1e": Agent1e,
}

def main():
    parser = argparse.ArgumentParser(description="Run a proof search agent.")
    parser.add_argument(
        "--theorems",
        type=str,
        default="theorems.txt",
        help="File containing theorems to prove.",
    )
    parser.add_argument(
        "--max_attempts", type=int, required=True, help="Max rollouts per task."
    )
    parser.add_argument(
        "--agent",
        type=str,
        required=True,
        help="Which agent to use (e.g., 1a, 1b, 1c, 1da, 1db, 1dc).",
    )
    parser.add_argument(
        "--seed",
        type=int,
        required=False,
        default=None,
        help="Initial random seed for reproducibility.",
    )
    args = parser.parse_args()

    if args.seed is not None:
        random.seed(args.seed)

    # Dynamically import the agent
    agent_name = "Agent" + args.agent
    try:
        agent = agents[args.agent]()
    except (ImportError, AttributeError) as e:
        print(f"Could not find or instantiate Agent {agent_name}: {e}")
        return

    # Read and parse theorems
    with open(args.theorems, "r") as f:
        content = f.read().strip()

    # Better parsing: remove comments and extract theorems
    # Remove comment lines
    lines = content.split("\n")
    clean_lines = []
    for line in lines:
        if not line.strip().startswith("#"):
            clean_lines.append(line)
    clean_content = "\n".join(clean_lines)

    # Split theorems by double newline
    theorem_texts = clean_content.strip().split("\n\n")
    theorems = []
    for theorem_text in theorem_texts:
        theorem_text = theorem_text.strip()
        if theorem_text and theorem_text.startswith("theorem "):
            theorems.append(theorem_text)

    num_successes = 0
    total_theorems = 0
    for theorem_text in theorems:
        theorem_text = theorem_text.strip()
        if not theorem_text:
            continue

        theorem_sig = theorem_text.split(":=")[0].strip()
        print(f"Attempting to prove: {theorem_sig}")

        try:
            initial_state = parse_theorem_signature(theorem_sig)
        except Exception as e:
            print(f"Failed to parse theorem: {e}")
            continue

        total_theorems += 1
        proof: Trajectory | None = None
        num_successful_rollouts = 0
        for i in range(args.max_attempts):
            # TODO: Your code for the main.py script goes here!
            # Each attempt should use the agent to perform a proof search.
            # The number of successful attempts should be counted in `num_successful_rollouts`.
            # If >= 1 successful rollout is found, populate `proof` with the trajectory of actions taken in that rollout.
            # (This is just to help you debug, and to see if the agent finds the same proofs as are listed in `theorems.txt`.)

            # YOUR CODE HERE
            pass

        if proof is not None:
            num_successes += 1  # found at least one successful proof
            print(
                f"{num_successful_rollouts}/{args.max_attempts} successful rollouts for this theorem."
            )
            print("Example proof:")
            for _, action in proof:
                print(f"  {action}")

        else:
            print("Proof failed. No successful rollouts.")

        print("-" * 20)

    print(f"Total successful proofs: {num_successes}/{total_theorems}")


if __name__ == "__main__":
    main()
