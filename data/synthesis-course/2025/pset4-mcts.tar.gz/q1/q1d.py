# You can modify the imports if you'd like
from env.state import ProofState, AbstractState
from q1c import Agent as Agent1c

# You aren't required to inherit from the earlier agent, but it may save you some work.
class Agent(Agent1c):
    # YOUR CODE HERE
    pass