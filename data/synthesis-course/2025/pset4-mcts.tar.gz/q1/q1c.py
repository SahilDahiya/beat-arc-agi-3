# You can modify the imports if you'd like
from env.state import Value
from env.interaction import Trajectory
from q1b import Agent as Agent1b


# You aren't required to inherit from the earlier agent, but it may save you some work.
class Agent(Agent1b):
    # YOUR CODE HERE
    pass