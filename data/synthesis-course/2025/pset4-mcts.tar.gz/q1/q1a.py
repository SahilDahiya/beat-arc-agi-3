# You can modify the imports if you'd like
import random
from collections import defaultdict
from env.state import ProofState, AbstractState, Value
from env.interaction import Trajectory, step
from env.actions import Action, ACTION_SPACE


class Agent:
    # YOUR CODE HERE
    pass
